Config = {
    NonSlipperyVehicles = {"sultan", "adder", "banshee", "comet", "t20"}, -- etkilenmeyecek araçların listesi
    CheckInterval = 4000 -- kaç saniyede bir olacağını belirler
}